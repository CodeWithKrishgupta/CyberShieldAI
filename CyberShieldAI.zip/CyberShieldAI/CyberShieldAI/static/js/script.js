// =========================================
// CyberShieldAI JavaScript
// =========================================

// Welcome Message
console.log("CyberShieldAI Loaded Successfully");

// =========================================
// Alert Message
// =========================================

function showAlert(message){

    alert(message);

}

// =========================================
// Form Validation
// =========================================

function validateForm(inputId){

    let input = document.getElementById(inputId);

    if(input.value.trim() === ""){

        alert("Input field cannot be empty!");

        return false;
    }

    return true;
}

// =========================================
// Dark Mode Toggle
// =========================================

function toggleDarkMode(){

    document.body.classList.toggle("dark-mode");

}

// =========================================
// Typing Animation
// =========================================

const text = "AI Powered Cybersecurity System";

let index = 0;

function typingEffect(){

    if(index < text.length){

        document.getElementById("typing-text").innerHTML += text.charAt(index);

        index++;

        setTimeout(typingEffect, 100);
    }
}

// Run typing effect
window.onload = function(){

    let typingElement = document.getElementById("typing-text");

    if(typingElement){

        typingEffect();
    }
};

// =========================================
// Loading Button Animation
// =========================================

function loadingButton(buttonId){

    let button = document.getElementById(buttonId);

    button.innerHTML = "Checking...";

    button.disabled = true;

}

// =========================================
// Copy Result
// =========================================

function copyResult(){

    let result = document.getElementById("result");

    navigator.clipboard.writeText(result.innerText);

    alert("Result Copied!");

}

// =========================================
// Dashboard Counter Animation
// =========================================

function animateCounter(id, target){

    let count = 0;

    let speed = target / 100;

    let interval = setInterval(function(){

        count += speed;

        document.getElementById(id).innerText =
            Math.floor(count);

        if(count >= target){

            document.getElementById(id).innerText = target;

            clearInterval(interval);
        }

    }, 20);
}