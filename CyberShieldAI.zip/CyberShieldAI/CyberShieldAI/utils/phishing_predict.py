# ==========================================
# PHISHING_PREDICT.PY
# ==========================================

import os
import pickle

# ==========================================
# BASE DIRECTORY
# ==========================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATH = os.path.abspath(os.path.join(
    BASE_DIR,
    "../models/phishing/phishing.pkl"
))

VECTORIZER_PATH = os.path.abspath(os.path.join(
    BASE_DIR,
    "../models/phishing/vectorizer.pkl"
))

# ==========================================
# LOAD MODEL
# ==========================================

with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

# ==========================================
# LOAD VECTORIZER
# ==========================================

with open(VECTORIZER_PATH, "rb") as f:
    vectorizer = pickle.load(f)

# ==========================================
# CLEAN URL
# ==========================================

def clean_url(url):

    url = url.strip().lower()

    if url.startswith("https://"):
        url = url.replace("https://", "", 1)

    elif url.startswith("http://"):
        url = url.replace("http://", "", 1)

    return url

# ==========================================
# PREDICT URL
# ==========================================

def predict_url(url):

    try:

        # Clean URL to match the training format
        url = clean_url(url)

        # Transform URL
        vector_input = vectorizer.transform([url])

        # Predict
        prediction = model.predict(vector_input)[0]

        print("Prediction:", prediction)

        # Handle string labels
        if prediction == "bad":
            return "PHISHING WEBSITE"

        elif prediction == "good":
            return "SAFE WEBSITE"

        # Handle numeric labels
        elif prediction == 0:
            return "PHISHING WEBSITE"

        elif prediction == 1:
            return "SAFE WEBSITE"

        else:
            return f"UNKNOWN RESULT: {prediction}"

    except Exception as e:

        return f"ERROR: {str(e)}"
