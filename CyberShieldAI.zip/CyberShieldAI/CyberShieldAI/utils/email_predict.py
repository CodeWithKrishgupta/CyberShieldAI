# ==========================================
# UTILS / EMAIL_PREDICT.PY
# ==========================================

import os
import pickle
import string
import nltk

from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

# ==========================================
# SETUP
# ==========================================

ps = PorterStemmer()
stop_words = set(stopwords.words('english'))

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

model = pickle.load(open(os.path.join(BASE_DIR, "../models/email/model.pkl"), "rb"))
vectorizer = pickle.load(open(os.path.join(BASE_DIR, "../models/email/vectorizer.pkl"), "rb"))

# ==========================================
# TEXT CLEANING
# ==========================================

def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)

    text = [word for word in text if word.isalnum()]
    text = [word for word in text if word not in stop_words]
    text = [ps.stem(word) for word in text]

    return " ".join(text)

# ==========================================
# PREDICTION
# ==========================================

def predict_email(message):
    transformed = transform_text(message)

    vector_input = vectorizer.transform([transformed])
    result = model.predict(vector_input)[0]

    return "Spam Email" if result == 1 else "Safe Email"