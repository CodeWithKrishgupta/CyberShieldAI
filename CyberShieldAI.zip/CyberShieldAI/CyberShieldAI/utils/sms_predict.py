import os
import pickle
import string
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

ps = PorterStemmer()

# ----------------------------
# BASE PATH
# ----------------------------
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

MODEL_PATH = os.path.join(BASE_DIR, "models", "sms", "model.pkl")
VECTORIZER_PATH = os.path.join(BASE_DIR, "models", "sms", "vectorizer.pkl")

# ----------------------------
# Load model
# ----------------------------
with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

with open(VECTORIZER_PATH, "rb") as f:
    tfidf = pickle.load(f)

# ----------------------------
# Stopwords
# ----------------------------
nltk.download("stopwords", quiet=True)
stop_words = set(stopwords.words("english"))

# ----------------------------
# Text cleaning
# ----------------------------
def transform_text(text):
    text = text.lower().split()

    cleaned = []
    for word in text:
        word = word.strip(string.punctuation)
        if word and word not in stop_words:
            cleaned.append(ps.stem(word))

    return " ".join(cleaned)

# ----------------------------
# Prediction
# ----------------------------
def predict_sms(text):
    processed = transform_text(text)
    vector = tfidf.transform([processed])

    result = model.predict(vector)[0]

    return "🚨 SPAM SMS" if result == 1 else "✅ NORMAL SMS"